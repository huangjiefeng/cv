You can download the source code to libfaac at
http://www.audiocoding.com/
