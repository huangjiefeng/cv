//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by encoder_aac.rc
//
#define IDB_BITMAP_LOGO                 101
#define IDS_APP_TITLE                   103
#define IDS_PAGE_AAC                    104
#define IDD_PAGE_AAC                    105
#define IDC_CB_VERSION                  1000
#define IDC_CB_TYPE                     1001
#define IDC_CB_BITRATE                  1002
#define IDC_CB_OUTPUT                   1003
#define IDC_LABEL_SAMPLERATE            1004
#define IDC_LABEL_CHANNELS              1005
#define IDC_LABEL_FRAMESIZE             1006
#define IDC_LABEL_FRAMES                1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
